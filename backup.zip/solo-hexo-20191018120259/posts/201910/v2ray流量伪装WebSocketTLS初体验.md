title: v2ray流量伪装：WebSocket + TLS 初体验
date: '2019-10-17 14:22:10'
updated: '2019-10-18 10:02:39'
tags: [待分类]
permalink: /articles/2019/10/17/1571322129907.html
---
### 写在前面
前段时间祖国妈妈生日，很多服务器都被封；之前用的是Shadowsocks的代理软件，只做了简单的混淆，导致我的几台服务器无一幸免，于是这两天研究了v2ray，加强混淆与伪装，并复活被Qiang主机。
### V2Ray介绍
V2Ray 是 Project V 下的一个工具。Project V 是一个包含一系列构建特定网络环境工具的项目，而 V2Ray 属于最核心的一个。 官方中介绍`Project V 提供了单一的内核和多种界面操作方式。内核（V2Ray）用于实际的网络交互、路由等针对网络数据的处理，而外围的用户界面程序提供了方便直接的操作流程。`不过从时间上来说，先有 V2Ray 才有 Project V。 如果还是不理解，那么简单地说，V2Ray 是一个与 Shadowsocks 类似的代理软件，可以用来科学上网（翻墙）学习国外先进科学技术。
### 前提条件
* 一台境外主机
* 一个域名，建议不使用备案的（避免喝茶）
* 域名申请证书，可以用免费的Let’s Encrypt证书，参考：[使用Let’s Encrypt的免费证书](https://tlanyan.me/use-lets-encrypt-certificate/)
* 配置步骤：
演示域名：`www.xmhz.ml，`服务器为linux（centos7），web服务器软件为nginx；预期结果：打开网址返回"bad request"
### 进入主题
#### 安装Nginx
执行:`yum install -y epel-release && yum install -y nginx`
 
系统如出现提示：No package nginx available；则需要配置repo源后，重新执行上面命令，如下：

```
[root@centos6-1 ~]# vim /etc/yum.repos.d/nginx.repo
#在文件中写入以下内容：
[nginx]
name=nginx repo
baseurl=http://nginx.org/packages/centos/$releasever/$basearch/
gpgcheck=0
enabled=1
```
linux系统上nginx默认站点配置文件是`/etc/nginx/conf.d/`目录下的`default.conf`，我们对伪装网站进行全站https配置，示例内容如下：
```
server {
    listen 80;
    server_name xxxxx;  # 改成你的域名
    rewrite ^(.*) https://$server_name$1 permanent;
}

server {
    listen       443 ssl http2;
    server_name xxxxx;
    charset utf-8;

    # ssl配置
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers ECDHE-RSA-AES256-GCM-SHA512:DHE-RSA-AES256-GCM-SHA512:ECDHE-RSA-AES256-GCM-SHA384:DHE-RSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-SHA384;
    ssl_ecdh_curve secp384r1;
    ssl_prefer_server_ciphers on;
    ssl_session_cache shared:SSL:10m;
    ssl_session_timeout 10m;
    ssl_session_tickets off;
    ssl_certificate xxxxx; # 改成你的证书地址
    ssl_certificate_key xxxx; # 改成证书密钥文件地址

    access_log  /var/log/nginx/access.log;
    error_log /var/log/nginx/error.log;

    root /usr/share/nginx/html; #这里是你网站位置
    location / {
        index  index.html;
       #下面这一段是进行反向代理，转发到v2ray，与V2ray配置的路径要保持一致
      	proxy_redirect off;
     	proxy_pass http://127.0.0.1:12345; # 假设v2ray的监听地址是12345
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;

    }
}
```
1.配置完成后检查有无错误：`nginx -t `，正确后重启：`systemctl restart nginx`，在浏览器输入域名，正常访问https的nginx欢迎页。
2.上传网站到nginx，默认位置：`/usr/share/nginx/html`。重启后再访问域名，这时候应该显示你的网站内容了。
3.增加反向代理，转发到V2ray。配置完成后重新，访问域名，这时候会报502错误，这是因为还没配置V2ray的原因。
```
server{
    XXXX
    XXXX
    root /usr/share/nginx/html; #这里是你网站位置
    location / {
       #这一段是进行反向代理，转发到v2ray，与V2ray配置的路径要保持一致,
       #因为我使用的是V2ray一键脚本,默认只能转发到 “/” 这个路径
      	proxy_redirect off;
     	proxy_pass http://127.0.0.1:12345; # 假设v2ray的监听地址是12345
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
	}
}
```
### 安装V2ray
安装必要软件 curl:`yum update -y && yum install curl -y`
V2ray 一键脚本：`bash <(curl -s -L https://git.io/v2ray.sh)`按照提示
