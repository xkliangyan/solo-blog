title: v2ray流量伪装：WebSocket + TLS 初体验
date: '2019-10-17 14:22:10'
updated: '2019-10-18 14:10:53'
tags: [Linux, v2ray]
permalink: /articles/2019/10/17/1571322129907.html
---
## 写在前面
前段时间祖国妈妈生日，很多服务器都被封；之前用的是Shadowsocks的代理软件，只做了简单的混淆，导致我的几台服务器无一幸免，于是这两天研究了v2ray，加强混淆与伪装，并复活被Qiang主机。
### V2Ray介绍
V2Ray 是 Project V 下的一个工具。Project V 是一个包含一系列构建特定网络环境工具的项目，而 V2Ray 属于最核心的一个。 官方中介绍`Project V 提供了单一的内核和多种界面操作方式。内核（V2Ray）用于实际的网络交互、路由等针对网络数据的处理，而外围的用户界面程序提供了方便直接的操作流程。`不过从时间上来说，先有 V2Ray 才有 Project V。 如果还是不理解，那么简单地说，V2Ray 是一个与 Shadowsocks 类似的代理软件，可以用来科学上网（翻墙）学习国外先进科学技术。
### 前提条件
* 一台境外主机，
* 一个域名，建议不使用备案的（避免喝茶概率），域名正确解析到主机
* 域名申请证书，可以用免费的Let’s Encrypt证书，参考：[使用Let’s Encrypt的免费证书](https://tlanyan.me/use-lets-encrypt-certificate/)
* 此文章操作基于Linux Centos7系统
### 进入主题

#### 安装Nginx
执行:`yum install -y epel-release && yum install -y nginx`
 
系统如出现提示：No package nginx available；则需要配置repo源后，重新执行上面命令，如下：

```
[root@centos6-1 ~]# vim /etc/yum.repos.d/nginx.repo
#在文件中写入以下内容：
[nginx]
name=nginx repo
baseurl=http://nginx.org/packages/centos/$releasever/$basearch/
gpgcheck=0
enabled=1
```
linux系统上nginx默认站点配置文件是`/etc/nginx/conf.d/`目录下的`default.conf`，我们对伪装网站进行全站https配置，示例内容如下：
```
server {
    listen 80;
    server_name xxxxx;  # 改成你的域名
    rewrite ^(.*) https://$server_name$1 permanent;
}

server {
    listen       443 ssl http2;
    server_name xxxxx;
    charset utf-8;

    # ssl配置
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers ECDHE-RSA-AES256-GCM-SHA512:DHE-RSA-AES256-GCM-SHA512:ECDHE-RSA-AES256-GCM-SHA384:DHE-RSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-SHA384;
    ssl_ecdh_curve secp384r1;
    ssl_prefer_server_ciphers on;
    ssl_session_cache shared:SSL:10m;
    ssl_session_timeout 10m;
    ssl_session_tickets off;
    ssl_certificate xxxxx; # 改成你的证书地址
    ssl_certificate_key xxxx; # 改成证书密钥文件地址

    access_log  /var/log/nginx/access.log;
    error_log /var/log/nginx/error.log;

    root /usr/share/nginx/html; #这里是你网站位置
    location / {
        index  index.html;
       #下面这一段是进行反向代理，转发到v2ray，与V2ray配置的路径要保持一致
      	proxy_redirect off;
     	proxy_pass http://127.0.0.1:12345; # 假设v2ray的监听地址是12345
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;

    }
}
```
1.配置完成后检查有无错误，命令：`nginx -t `，正确后重启，命令：`systemctl restart nginx`，在浏览器输入域名，正常访问https的nginx欢迎页。
2.上传网站到nginx，默认位置：`/usr/share/nginx/html`。重启后再访问域名，这时候应该显示你的网站内容了。
3.增加反向代理，转发到V2ray。配置完成后重启，访问域名，这时候会报502错误，这是因为还没配置V2ray的原因。
```
server{
    XXXX
    XXXX
    root /usr/share/nginx/html; #这里是你网站位置
    index index.html
    location /xkliangyan/xmhz {
       #这一段是进行反向代理，转发到v2ray，与V2ray配置的路径要保持一致
      	proxy_redirect off;
     	proxy_pass http://127.0.0.1:12345; # 假设v2ray的监听地址是12345
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
	}
}
```
#### 配置V2ray
安装V2ray参考[官方文档](https://toutyrater.github.io/)
配置config.json，命令：`vim /etc/v2ray/config.json`，接受nginx传来的数据。在“inbounds”中新增“streamSetting”配置，传输协议使用“websocket”。

**注意**：json文件不支持注释，下述配置中”#”号及后续内容都要删掉。

```
{
  "log": {
    "loglevel": "warning",
    "access": "/var/log/v2ray/access.log",
    "error": "/var/log/v2ray/error.log"
   },
  "inbounds": [{
    "port": 12345,   #监听端口
    "protocol": "vmess",
    "settings": {
      "clients": [
        {
          "id": "xxxxx", # 可以使用v2ctl uuid生成
          "level": 1,
          "alterId": 4 # 数值越大，占用资源越多
        }
      ]
    },
    "streamSettings": {     
        "network": "ws", # 载体配置段，设置为websocket
        "wsSettings": {
          "path": "/xkliangyan/xmhz"  # 与nginx中的路径保持一致
        }
      },
    "listen": "127.0.0.1" # 只允许本地的连接，出于安全考虑
  }],
  "outbounds": [{
    "protocol": "freedom",
    "settings": {}
  },{
    "protocol": "blackhole",
    "settings": {},
    "tag": "blocked"
  }],
  "routing": {
    "rules": [
      {
        "type": "field",
        "ip": ["geoip:private"],
        "outboundTag": "blocked"
      }
    ]
  }
}
```
配置完成，检测内容是否无误，命令：`cat /etc/v2ray/config.json`，重启v2ray服务：`systemctl restart v2ray`。进行测试验证，输入域名或其它路径，应正常访问或提示404等，输入vRay特定路径，例如：`www.域名.com\xkliangyan\xmhz`返回"bad request"，说明nginx将流量转发给了v2ray，并且v2ray收到了请求。我们从外部看起来完全是一个人畜无害的正规网站，特定手段请求特定网址才是科学上网的通道。
#### 客户端设置
Windows平台的v2rayN软件为例说明使用方法。
打开v2rayN，服务器-添加[Vmess]服务器，截图如下：
![blog1.jpg](https://img.hacpai.com/file/2019/10/blog1-c9bd76fb.jpg)
确定后，右下角图标右键，开启HTTP代理，打开游览器，访问google、youtube正常即成功了。

#### 复活被Qiang主机
思路：**WebSocket + TLS+CloudflareCDN**，内容不细写。

## End

